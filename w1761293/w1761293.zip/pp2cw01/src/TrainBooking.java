import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class TrainBooking extends Application {               //Start Of the Main Method

    static final int SEAT_CAPACITY = 42;
    private static final int SEATING_CAPACITY = 42;

    public static void main(String[] args) {

        launch();
    }

    // Create Starting Method
    @Override
    public void start(Stage primaryStage) throws IOException, InterruptedException {
        String[] mainArray = new String[SEAT_CAPACITY];                                   //Creating Arrays
        String[] mainArray1 = new String[SEAT_CAPACITY];                                  //Creating Arrays
        Scanner input = new Scanner(System.in);

        menu:
        while (true) {                                       // Main Menu to Display in Console
            System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            System.out.println("!!!!!!!!>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<!!!!!!!!!!");
            System.out.println("!!!..Welcome To Denuwara Manike Intercity Train Seats Booking System..!!!\n ...Please Select an option According to your Requirement... ");
            System.out.println("!!!!!!!!>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<!!!!!!!!!!");
            System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            System.out.println("Enter \"A\" to add a Customer:");
            System.out.println("Enter \"V\" to view all Seats:");
            System.out.println("Enter \"E\" to view empty seats:");
            System.out.println("Enter \"D\" to delete booked seats:");
            System.out.println("Enter \"F\" to find a seat by customer name:");
            System.out.println("Enter \"S\" to store program data:");
            System.out.println("Enter \"L\" to Load program data from file:");
            System.out.println("Enter \"O\" to View seats Ordered alphabetically by name:");
            System.out.println("Enter \"Q\" to Quit:");

            System.out.println("Select an option According to your Requirement :");
            String option = input.next();
            switch (option) {                                              //Select an Options.........

                case "A":                                     // To Add New Customer
                case "a":
                    addCustomer(mainArray, mainArray1);
                    break;

                case "V":                                    // To View All Seats
                case "v":
                    viewAllSeats(mainArray, mainArray1);
                    break;

                case "E":                                    // To View Empty Seats
                case "e":
                    viewEmptySeats(mainArray, mainArray1);
                    break;


                case "D":                                   // To  Delete Stored Data
                case "d":
                    deleteSeats(mainArray, mainArray1);
                    break;

                case "F":                                  // To Find Customer by Name
                case "f":
                    findCustomer(mainArray, mainArray1);
                    break;

                case "S":                                  // To  Stored Data
                case "s":
                    storeFile(mainArray, mainArray1);
                    break;

                case "L":                                  // To Load Stored Data
                case "l":
                    loadFile(mainArray, mainArray1);
                    break;

                case "O":                                 // To view Names Alphabetically
                case "o":
                    viewAlphabeticallyByName(mainArray, mainArray1);
                    break;


                case "Q":                                 //To Execute the Program
                case "q":
                    Quit();

                    break menu;
                default:
                    System.out.println("Invalid Input...????...Please Select Option Again...!!!!");
            }
        }
    }

    private String[] addCustomer(String[] mainArray, String[] mainArray1) {            // Creating Method For Delete Seats
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Your Name First : ");                                   //Getting a Name to Add to the List
        String name = sc.next();
        System.out.println("Enter 1 to book a seat from Colombo to Badulla :");          //Select the Trip You Want to Book Seats
        System.out.println("Enter 2 to book a seat from Badulla to Colombo :");
        try {
            int select1 = sc.nextInt();
            if (select1 == 1) {                                            //Add customers for trip from Colombo to Badulla
                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");                             //Set Buttons.!!!!!!!
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");

                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};

                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");         // set Styles for Buttons
                }
                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray[i] != null) {
                        buttons[i].setStyle("-fx-background-color: red;");       //Set color for the buttons in set on Actions
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                    //Creating an Label

                GridPane root = new GridPane();

                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);
                root.add(btn16, 6, 7, 1, 1);
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);         // Set the Position Of the Buttons
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);

                for (int i = 0; i < 42; i++) {
                    int tempory = i;
                    buttons[i].setOnAction((Event) -> {
                        tempList.add(tempory + 1);
                        buttons[tempory].setStyle("-fx-background-color:red;");

                    });
                }
                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {                   //Set color for the buttons in set on Actions
                        mainArray[tempList.get(x) - 1] = name;
                    }
                    newStage.close();
                });
                newStage.setTitle("Add New Customer");
                root.setHgap(10);
                root.setVgap(10);
                Scene scene = new Scene(root, 600, 600);           //Designing Gridepane
                newStage.setScene(scene);
                newStage.showAndWait();
                return mainArray;

            } else if (select1 == 2) {                                  //Add customers for trip from Badulla to Colombo
                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");                        //Set Buttons.!!!!!!!
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");

                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};

                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");              // set Styles for Buttons
                }
                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray1[i] != null) {
                        buttons[i].setStyle("-fx-background-color: red;");               //Set color for the buttons in set on Actions
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                           //Creating an Label

                GridPane root = new GridPane();

                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);
                root.add(btn16, 6, 7, 1, 1);
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);            // Set the Position Of the Buttons
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);

                for (int i = 0; i < 42; i++) {
                    int tempory = i;
                    buttons[i].setOnAction((Event) -> {
                        tempList.add(tempory + 1);
                        buttons[tempory].setStyle("-fx-background-color:red;");

                    });
                }
                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {
                        mainArray1[tempList.get(x) - 1] = name;                    //Set color for the buttons in set on Actions
                    }
                    newStage.close();
                });
                newStage.setTitle("Add New Customer");
                root.setHgap(10);
                root.setVgap(10);
                Scene scene = new Scene(root, 600, 600);
                newStage.setScene(scene);
                newStage.showAndWait();

            } else {
                System.out.println("Invalid Input.......!!!!!!!");
            }
            return mainArray1;
        } catch (Exception e) {
            System.out.println("Invalid Input.......!!!!!!!");
        }
        return null;

    }

    private String[] viewAllSeats(String[] mainArray, String[] mainArray1) {              // Creating Method For View All Seats
        Scanner sc = new Scanner(System.in);
        System.out.println("Press 1 to View all seats from Colombo to Badulla :");         //Select the Trip You Want to View Seats
        System.out.println("Press 2 to View all seats from Badulla to Colombo :");
        try {
            int select1 = sc.nextInt();
            if (select1 == 1) {                                          //View Seats for trip from Colombo to Badulla
                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");                           //Set Buttons.!!!!!!!
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");


                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};
                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");            // set Styles for Buttons
                }

                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray[i] != null) {
                        buttons[i].setStyle("-fx-background-color: red;");            //Set color for the buttons in set on Actions
                        buttons[i].setMouseTransparent(true);
                    } else {
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                     //Creating an Label


                GridPane root = new GridPane();
                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);
                root.add(btn16, 6, 7, 1, 1);
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);                      // Set the Position Of the Buttons
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);


                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {                     //Set color for the buttons in set on Actions
                        String name = null;
                        mainArray[tempList.get(x) - 1] = name;
                    }
                    newStage.close();
                });

                newStage.setTitle("View All Seats");


                root.setHgap(10);
                root.setVgap(10);

                Scene scene = new Scene(root, 600, 600);
                newStage.setScene(scene);
                newStage.showAndWait();
                return mainArray;
            } else if (select1 == 2) {                                  //View Seats for trip from Badulla to Colombo
                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");                        //Set Buttons.!!!!!!!
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");


                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};
                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");            // set Styles for Buttons
                }

                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray1[i] != null) {
                        buttons[i].setStyle("-fx-background-color: red;");
                        buttons[i].setMouseTransparent(true);
                    } else {
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                         //Creating an Label


                GridPane root = new GridPane();
                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);
                root.add(btn16, 6, 7, 1, 1);                // Set the Position Of the Buttons
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);


                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {                  //Set color for the buttons in set on Actions
                        String name = null;
                        mainArray1[tempList.get(x) - 1] = name;
                    }
                    newStage.close();
                });

                newStage.setTitle("View All Seats");


                root.setHgap(10);
                root.setVgap(10);

                Scene scene = new Scene(root, 600, 600);
                newStage.setScene(scene);
                newStage.showAndWait();
            } else {
                System.out.println("Invalid Input...!!!!!!");
            }
            return mainArray1;
        } catch (Exception e) {
            System.out.println("Invalid Input...!!!!!!");
            System.out.println();
        }
        return null;
    }

    private String[] viewEmptySeats(String[] mainArray, String[] mainArray1) {             // Creating Method For View Empty Seats
        Scanner sc = new Scanner(System.in);
        System.out.println("Press 1 to View Empty seats from Colombo to Badulla :");        //Select the Trip You Want to View Empty Seats
        System.out.println("Press 2 to View Empty seats from Badulla to Colombo :");
        try {
            int select1 = sc.nextInt();
            if (select1 == 1) {                                              //View Empty Seats for trip from colombo to Badulla

                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");                                  //Set Buttons.!!!!!!!
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");


                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};
                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");                 // set Styles for Buttons
                }

                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray[i] != null) {
                        buttons[i].setVisible(false);                                    //Set color for the buttons in set on Actions
                        buttons[i].setMouseTransparent(true);
                    } else {
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                           //Creating an Label


                GridPane root = new GridPane();
                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);                       // Set the Position Of the Buttons
                root.add(btn16, 6, 7, 1, 1);
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);

                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {
                        String name = null;
                        mainArray[tempList.get(x) - 1] = name;
                    }
                    newStage.close();
                });

                newStage.setTitle("Empty Seats");

                root.setHgap(10);
                root.setVgap(10);

                Scene scene = new Scene(root, 600, 600);
                newStage.setScene(scene);
                newStage.showAndWait();
                return mainArray;
            } else if (select1 == 2) {                                   //View Empty Seats for trip from Badulla to Colombo
                ArrayList<Integer> tempList = new ArrayList<>();
                Button btn1 = new Button("Seat NO 01");
                Button btn2 = new Button("Seat NO 02");
                Button btn3 = new Button("Seat NO 03");
                Button btn4 = new Button("Seat NO 04");
                Button btn5 = new Button("Seat NO 05");
                Button btn6 = new Button("Seat NO 06");
                Button btn7 = new Button("Seat NO 07");
                Button btn8 = new Button("Seat NO 08");
                Button btn9 = new Button("Seat NO 09");
                Button btn10 = new Button("Seat NO 10");
                Button btn11 = new Button("Seat NO 11");
                Button btn12 = new Button("Seat NO 12");
                Button btn13 = new Button("Seat NO 13");
                Button btn14 = new Button("Seat NO 14");
                Button btn15 = new Button("Seat NO 15");
                Button btn16 = new Button("Seat NO 16");
                Button btn17 = new Button("Seat NO 17");
                Button btn18 = new Button("Seat NO 18");
                Button btn19 = new Button("Seat NO 19");
                Button btn20 = new Button("Seat NO 20");                                   //Set Buttons.!!!!!!!
                Button btn21 = new Button("Seat NO 21");
                Button btn22 = new Button("Seat NO 22");
                Button btn23 = new Button("Seat NO 23");
                Button btn24 = new Button("Seat NO 24");
                Button btn25 = new Button("Seat NO 25");
                Button btn26 = new Button("Seat NO 26");
                Button btn27 = new Button("Seat NO 27");
                Button btn28 = new Button("Seat NO 28");
                Button btn29 = new Button("Seat NO 29");
                Button btn30 = new Button("Seat NO 30");
                Button btn31 = new Button("Seat NO 31");
                Button btn32 = new Button("Seat NO 32");
                Button btn33 = new Button("Seat NO 33");
                Button btn34 = new Button("Seat NO 34");
                Button btn35 = new Button("Seat NO 35");
                Button btn36 = new Button("Seat NO 36");
                Button btn37 = new Button("Seat NO 37");
                Button btn38 = new Button("Seat NO 38");
                Button btn39 = new Button("Seat NO 39");
                Button btn40 = new Button("Seat NO 40");
                Button btn41 = new Button("Seat NO 41");
                Button btn42 = new Button("Seat NO 42");
                Button exit = new Button("Exit");
                exit.setStyle("-fx-background-color: yellow;");


                Button[] buttons = {btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, btn14, btn15, btn16, btn17,
                        btn18, btn19, btn20, btn21, btn22, btn23, btn24, btn25, btn26, btn27, btn28, btn29, btn30, btn31, btn32, btn33, btn34, btn35,
                        btn36, btn37, btn38, btn39, btn40, btn41, btn42};
                for (int i = 0; i < 42; i++) {
                    buttons[i].setStyle("-fx-background-color: green;");                    // set Styles for Buttons
                }

                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (mainArray1[i] != null) {
                        buttons[i].setVisible(false);
                        buttons[i].setMouseTransparent(true);                                 //Set color for the buttons in set on Actions
                    } else {
                        buttons[i].setMouseTransparent(true);
                    }
                }
                Label lbl = new Label("***Welcome to Denuwara Manike Train Booking***\n       Click  On  the  Seat  you  Want  to  Book");
                lbl.setStyle("-fx-background-color: white;");                                  //Creating an Label


                GridPane root = new GridPane();
                root.add(btn1, 1, 4, 1, 1);
                root.add(btn2, 2, 4, 1, 1);
                root.add(btn3, 5, 4, 1, 1);
                root.add(btn4, 6, 4, 1, 1);
                root.add(btn5, 1, 5, 1, 1);
                root.add(btn6, 2, 5, 1, 1);
                root.add(btn7, 5, 5, 1, 1);
                root.add(btn8, 6, 5, 1, 1);
                root.add(btn9, 1, 6, 1, 1);
                root.add(btn10, 2, 6, 1, 1);
                root.add(btn11, 5, 6, 1, 1);
                root.add(btn12, 6, 6, 1, 1);
                root.add(btn13, 1, 7, 1, 1);
                root.add(btn14, 2, 7, 1, 1);
                root.add(btn15, 5, 7, 1, 1);
                root.add(btn16, 6, 7, 1, 1);
                root.add(btn17, 1, 8, 1, 1);
                root.add(btn18, 2, 8, 1, 1);
                root.add(btn19, 5, 8, 1, 1);
                root.add(btn20, 6, 8, 1, 1);
                root.add(btn21, 1, 9, 1, 1);
                root.add(btn22, 2, 9, 1, 1);
                root.add(btn23, 5, 9, 1, 1);
                root.add(btn24, 6, 9, 1, 1);
                root.add(btn25, 1, 10, 1, 1);
                root.add(btn26, 2, 10, 1, 1);
                root.add(btn27, 5, 10, 1, 1);
                root.add(btn28, 6, 10, 1, 1);
                root.add(btn29, 1, 11, 1, 1);
                root.add(btn30, 2, 11, 1, 1);
                root.add(btn31, 5, 11, 1, 1);
                root.add(btn32, 6, 11, 1, 1);
                root.add(btn33, 1, 12, 1, 1);
                root.add(btn34, 2, 12, 1, 1);
                root.add(btn35, 5, 12, 1, 1);
                root.add(btn36, 6, 12, 1, 1);
                root.add(btn37, 1, 13, 1, 1);
                root.add(btn38, 2, 13, 1, 1);
                root.add(btn39, 5, 13, 1, 1);
                root.add(btn40, 6, 13, 1, 1);
                root.add(btn41, 1, 14, 1, 1);
                root.add(btn42, 6, 14, 1, 1);
                root.add(exit, 4, 16, 1, 1);
                root.add(lbl, 2, 1, 6, 1);

                Stage newStage = new Stage();

                exit.setOnAction((Event) -> {
                    for (int x = 0; x < tempList.size(); x++) {
                        String name = null;
                        mainArray1[tempList.get(x) - 1] = name;
                    }
                    newStage.close();
                });

                newStage.setTitle("Empty Seats");

                root.setHgap(10);
                root.setVgap(10);

                Scene scene = new Scene(root, 600, 600);
                newStage.setScene(scene);
                newStage.showAndWait();
            } else {
                System.out.println("Invalid Input....!!!!!");

            }
            return mainArray1;
        } catch (Exception e) {
            System.out.println("Invalid Input...!!!!!!");
            System.out.println();
        }
        return null;
    }

    private void deleteSeats(String[] mainArray, String[] mainArray1) {                   // Creating Method For Delete Seats
        Scanner scc = new Scanner(System.in);
        System.out.println("Enter 1 to Delete Records from Colombo to Badulla :");          //Select the Trip You Want to Delete Booked Seats
        System.out.println("Enter 2 to Delete Records from Badulla to Colombo :");
        try {
            int select1 = scc.nextInt();
            if (select1 == 1) {                                                        // Delete Bookings  from Colombo to Badulla
                boolean value = Boolean.TRUE;
                while (value) {
                    int passenger;
                    Scanner sc = new Scanner(System.in);
                    System.out.print("Enter the Seat Number you should want to delete : ");      //Asking what seat should delete
                    try {
                        passenger = sc.nextInt();
                    } catch (Exception e) {
                        System.out.println("Invalid Input");
                        continue;                                                               //Checking that seat booking and deleting
                    }
                    if (passenger < 1 || passenger > SEATING_CAPACITY) {
                        System.out.println("Invalid Input");
                        continue;
                    }
                    if (mainArray[passenger - 1] != null) {
                        value = false;
                        mainArray[passenger - 1] = null;
                        System.out.println("Record Deleted !");
                        System.out.println();
                    } else {
                        value = false;
                        System.out.println("No Records Found");
                    }
                }
            } else if (select1 == 2) {
                boolean value = Boolean.TRUE;                                        //Delete Bookings  from Badulla to Colombo
                while (value) {
                    int passenger;
                    Scanner sc = new Scanner(System.in);
                    System.out.print("Enter the Seat number you should want to delete : ");      //Asking what seat should delete
                    try {
                        passenger = sc.nextInt();
                    } catch (Exception e) {
                        System.out.println("Invalid Input");
                        continue;                                                               //Checking that seat booking and deleting
                    }
                    if (passenger < 1 || passenger > SEATING_CAPACITY) {
                        System.out.println("Invalid Input");
                        continue;
                    }
                    if (mainArray1[passenger - 1] != null) {
                        value = false;
                        mainArray1[passenger - 1] = null;
                        System.out.println("Record Deleted !");
                        System.out.println();
                    } else {
                        value = false;
                        System.out.println("No Records Found");
                    }
                }
            } else {
                System.out.println("Invalid Input");
                System.out.println();

            }

        } catch (Exception e) {
            System.out.println("Invalid Input...!!!!! ");
        }
    }

    private void findCustomer(String[] mainArray, String[] mainArray1) {                                      // Creating Method For Find Customer by Name
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 1 to Find Customer from Colombo to Badulla:");                              //Select the Trip You Want to Find Customer by Name
        System.out.println("Enter 2 to Find Customer from Badulla to Colombo:");


            int select1 = sc.nextInt();
            if (select1 == 1) {
                try {
                    Scanner select = new Scanner(System.in);
                    System.out.println("Enter the Customer Name you should want to find:");               //Asking Name to find from Array1
                    String name = select.nextLine();
                    ArrayList<Integer> selected = new ArrayList();

                                                                                                       //Get Matching Names Array1
                    for (int i = 0; i < SEAT_CAPACITY; i++) {
                        if (name.equalsIgnoreCase(mainArray[i])) {
                            selected.add(i + 1);
                        }
                    }
                    if (selected.size() == 0) {
                        System.out.println("No Records Found...!!!!");
                    } else {
                        System.out.println(name + " Booked Seat Number " + Arrays.toString(selected.toArray()) + " from Colombo to Badulla");
                    }


                }catch (Exception e) {
                    System.out.println("Invalid Input!!");
                }

            }else if (select1==2){
                try{
                Scanner select = new Scanner(System.in);
                System.out.println("Enter the Customer Name you should want to find:");                //Asking Name to find from Array2
                String name = select.nextLine();
                ArrayList<Integer> selected = new ArrayList();

                                                                                          //Get Matching Names from Array2
                for (int i = 0; i < SEAT_CAPACITY; i++) {
                    if (name.equalsIgnoreCase(mainArray1[i])) {
                        selected.add(i + 1);
                    }
                }
                if (selected.size() == 0) {
                    System.out.println("No Records Found...!!!!");
                } else {
                    System.out.println ( name + " Booked Seat Number" + Arrays.toString(selected.toArray()) + " from  Badulla To Colombo ");
                }


            }catch (Exception e){
                    System.out.println("Invalid ...!!");
                }
        }else {
                System.out.println("Invalid ...!!");

            }

    }

    private void storeFile(String[]mainArray,String[]mainArray1) throws IOException {                         //  Creating Method For store File And Data
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 1 to Save Data from Colombo to Badulla :");                                 //Select the Trip You Want to Store Files And Data
        System.out.println("Enter 2 to Save Data from Badulla to Colombo :");
        int select1 = sc.nextInt();
        if (select1 == 1) {
            try (PrintWriter out = new PrintWriter(new FileWriter("E:\\Trip1.txt"))) {             //Creating Path For Save Data in Text Files
                int s;
                for (s = 0; s < SEATING_CAPACITY; s++) {
                    if (s < 9) {
                        out.println("Seat Number  " + (s + 1) + " Booked by " + mainArray[s]);
                    } else {
                        out.println("Seat Number " + (s + 1) + " Booked by " + mainArray[s]);
                    }
                }


            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            }
        } else if (select1 == 2) {
            try (PrintWriter out = new PrintWriter(new FileWriter("E:\\Trip2.txt"))) {                    //Creating Path For Save Data in Text Files
                int s;
                for (s = 0; s < SEATING_CAPACITY; s++) {
                    if (s < 9) {
                        out.println("Seat Number  " + (s + 1) + " Booked by " + mainArray1[s]);
                    } else {
                        out.println("Seat Number " + (s + 1) + " Booked by " + mainArray1[s]);
                    }
                }


            } catch (FileNotFoundException e) {
                System.out.println("File Not Found");
            }

        }
        System.out.println("All Names have been Saved");
    }

    private void loadFile (String[]mainArray,String[]mainArray1) throws IOException {         // Creating Method For Load Files
           Scanner sc = new Scanner(System.in);
           System.out.println("Enter 1 to Loads Data from Colombo to Badulla :");          //Select the Trip You Want to Load Files
           System.out.println("Enter 2 to Loads Data from Badulla to Colombo :");

                BufferedReader objReader = null;
                int i = 0;
                try {
                    int select1 = sc.nextInt();
                    if (select1 == 1) {
                        String strCurrentLine;
                        objReader = new BufferedReader(new FileReader("E:\\Trip1.txt"));               //reading text file
                        while ((strCurrentLine = objReader.readLine()) != null) {

                                                                                                                //storing the passengers name in to name variable
                            String name = strCurrentLine.substring(25, strCurrentLine.length());
                            if (!"null".equals(name)) {
                                //storing the passengers name in to seats array                                 //storing the passengers name in to Array2
                                mainArray[i] = name;
                            }
                            i++;
                        }
                    }else if (select1 == 2){
                        String strCurrentLine;
                        objReader = new BufferedReader(new FileReader("E:\\Trip2.txt"));                //reading text file
                        while ((strCurrentLine = objReader.readLine()) != null) {

                                                                                                                //storing the passengers name in to name variable
                            String name = strCurrentLine.substring(25, strCurrentLine.length());
                            if (!"null".equals(name)) {
                                                                                                                //storing the passengers name in to Array2
                                mainArray1[i] = name;
                            }
                            i++;
                        }
                    }

                } catch (IOException e) {

                    e.printStackTrace();

                } finally {

                    try {
                        if (objReader != null)
                            objReader.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
        System.out.println("Loading Completed...!!!!!");
            }

    private void viewAlphabeticallyByName (String[]mainArray, String[]mainArray1) {           // Creating Method For View Names According ti Alphabetical Oder
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 1 to View Sort Oder from Colombo to Badulla ");            //Select the Trip You Want Sort Names
        System.out.println("Enter 2 to View Sort Oder from Badulla to Colombo ");

        int select1 = sc.nextInt();
        if (select1 == 1) {
        ArrayList<String> enteredNames = new ArrayList<>();
        for (int k = 0; k < SEAT_CAPACITY; k++) {                                           //Cheaking Names From Array 1

            if (mainArray[k] != null) {
                enteredNames.add(  mainArray[k] + " booked Seat No " + Integer.toString(k + 1));
            }
        }
        if (enteredNames.size() == 0) {
            System.out.println(" No Records Found..!!!");
            return;
        }
        Boolean alph = Boolean.TRUE;
        String str = new String("");

        while (alph) {
            for (int k = 0; k < enteredNames.size(); k++) {
                for (int r = 0; r < enteredNames.size(); r++) {

                    alph = false;
                    if (enteredNames.get(k).compareToIgnoreCase(enteredNames.get(r)) < 0) {
                        str = enteredNames.get(k);
                        enteredNames.set(k, enteredNames.get(r));
                        enteredNames.set(r, str);
                        alph = true;
                    }
                }
            }
        }                                                                                    //Print Sorted Names from Array1 to console
        for (int k = 0; k < enteredNames.size(); k++) {
            System.out.println(enteredNames.get(k));

        }
    }else if (select1 == 2){
            ArrayList<String> enteredNames = new ArrayList<>();
            for (int k = 0; k < SEAT_CAPACITY; k++) {                                          //Cheaking Names From Array 2

                if (mainArray1[k] != null) {
                    enteredNames.add( mainArray1[k] + " booked Seat No " + Integer.toString(k + 1));
                }
            }
            if (enteredNames.size() == 0) {
                System.out.println(" No Records Found..!!!");
                return;
            }
            Boolean alph = Boolean.TRUE;
            String str = new String("");

            while (alph) {
                for (int k = 0; k < enteredNames.size(); k++) {
                    for (int r = 0; r < enteredNames.size(); r++) {
                        alph = false;
                        if (enteredNames.get(k).compareToIgnoreCase(enteredNames.get(r)) < 0) {
                            str = enteredNames.get(k);
                            enteredNames.set(k, enteredNames.get(r));
                            enteredNames.set(r, str);
                            alph = true;
                        }
                    }
                }
            }                                                                               //Print Sorted Names from Array2 to console
            for (int k = 0; k < enteredNames.size(); k++) {
                System.out.println(enteredNames.get(k));

            }
        }else{
            System.out.println("Invalid Input...!!!!");
        }
    }

    private void Quit () {                                                          // To Quit From the Program
        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        System.out.println("!!!!!!!!>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<!!!!!!!!!!");
        System.out.println("!!..Thank You for Using SriLankan Railway Booking System..!!");
        System.out.println("!!!!!!!!>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<!!!!!!!!!!");
        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        System.exit(0);
    }
    }                            // THE END.....!!!!!!! //


